package com.spoiledseed.guide;

import com.spoiledseed.config.ModConfig;
import com.spoiledseed.quest.QuestData;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent;

/** The guide book comes with the player: first join, and again after every respawn if it was lost. */
public class GuideHandler {
    @SubscribeEvent
    public void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (!ModConfig.giveGuideBook || !(e.player instanceof EntityPlayerMP)) return;
        if (!QuestData.isGuideGiven(e.player)) {
            give(e.player);
            QuestData.setGuideGiven(e.player, true);
        }
    }

    @SubscribeEvent
    public void onRespawn(PlayerEvent.PlayerRespawnEvent e) {
        if (!ModConfig.giveGuideBook || !(e.player instanceof EntityPlayerMP)) return;
        if (!GuideBook.has(e.player)) give(e.player);
    }

    public static void give(EntityPlayer p) {
        ItemStack book = GuideBook.create();
        if (!p.inventory.addItemStackToInventory(book)) p.entityDropItem(book, 0F);
    }
}
