package com.spoiledseed.horror;

import com.spoiledseed.SpoiledSeed;
import com.spoiledseed.registry.ModSounds;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.BlockDoor;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityChest;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.WorldServer;

/** Ways The Null disturbs the world without being seen: sounds, torches, doors, theft. */
public class WorldPranks {
    private static final Random RAND = new Random();

    private static class Relight { WorldServer w; BlockPos pos; IBlockState state; int ticks; }
    private static final List<Relight> RELIGHTS = new ArrayList<Relight>();

    // ---- sounds ---------------------------------------------------------------------------
    public static void footsteps(final EntityPlayerMP p) {
        Vec3d look = p.getLookVec();
        double bx = -look.xCoord, bz = -look.zCoord, l = Math.sqrt(bx * bx + bz * bz);
        if (l < 0.01D) { bx = 0D; bz = -1D; l = 1D; }
        final double ux = bx / l, uz = bz / l;
        final WorldServer w = (WorldServer) p.worldObj;
        for (int i = 0; i < 7; i++) {
            final double dist = 9D - i * 1.1D;                 // walking up behind the player
            Scheduler.schedule(i * 11 + 1, new Runnable() {
                @Override public void run() {
                    if (p.isDead) return;
                    w.playSound(null, p.posX + ux * dist, p.posY, p.posZ + uz * dist, ModSounds.FOOTSTEP,
                            SoundCategory.HOSTILE, 1.0F, 0.85F + RAND.nextFloat() * 0.3F);
                }
            });
        }
    }

    public static void knock(EntityPlayerMP p) {
        double ang = RAND.nextDouble() * Math.PI * 2D;
        p.worldObj.playSound(null, p.posX + Math.cos(ang) * 2.5D, p.posY + 1D, p.posZ + Math.sin(ang) * 2.5D,
                ModSounds.KNOCK, SoundCategory.HOSTILE, 1.4F, 1F);
    }

    public static void whisper(EntityPlayerMP p) {
        Vec3d look = p.getLookVec();
        p.worldObj.playSound(null, p.posX - look.xCoord * 1.2D, p.posY + 1.4D, p.posZ - look.zCoord * 1.2D,
                ModSounds.WHISPER, SoundCategory.HOSTILE, 1.3F, 0.85F + RAND.nextFloat() * 0.2F);
    }

    public static void distantSound(EntityPlayerMP p) {
        SoundEvent[] pool = new SoundEvent[] { ModSounds.DRONE, ModSounds.SCRAPE, ModSounds.BREATH };
        double ang = RAND.nextDouble() * Math.PI * 2D, d = 8D + RAND.nextDouble() * 8D;
        p.worldObj.playSound(null, p.posX + Math.cos(ang) * d, p.posY, p.posZ + Math.sin(ang) * d,
                pool[RAND.nextInt(pool.length)], SoundCategory.AMBIENT, 1.3F, 0.8F + RAND.nextFloat() * 0.3F);
    }

    // ---- torches --------------------------------------------------------------------------
    public static void extinguish(EntityPlayerMP p) {
        WorldServer w = (WorldServer) p.worldObj;
        BlockPos c = new BlockPos(p);
        List<BlockPos> found = new ArrayList<BlockPos>();
        for (int x = -8; x <= 8; x++)
            for (int y = -4; y <= 4; y++)
                for (int z = -8; z <= 8; z++) {
                    BlockPos b = c.add(x, y, z);
                    if (w.getBlockState(b).getBlock() == Blocks.TORCH) found.add(b);
                }
        Collections.shuffle(found, RAND);
        for (int i = 0; i < Math.min(3, found.size()); i++) {
            BlockPos b = found.get(i);
            Relight rl = new Relight();
            rl.w = w; rl.pos = b; rl.state = w.getBlockState(b); rl.ticks = (30 + RAND.nextInt(40)) * 20;
            RELIGHTS.add(rl);
            w.setBlockState(b, Blocks.AIR.getDefaultState());
            w.playSound(null, b.getX() + 0.5D, b.getY() + 0.5D, b.getZ() + 0.5D, SoundEvents.BLOCK_FIRE_EXTINGUISH, SoundCategory.BLOCKS, 0.6F, 1F);
        }
    }

    public static void tick() {
        if (RELIGHTS.isEmpty()) return;
        for (Iterator<Relight> it = RELIGHTS.iterator(); it.hasNext();) {
            Relight rl = it.next();
            if (--rl.ticks <= 0) { relight(rl); it.remove(); }
        }
    }

    private static void relight(Relight rl) {
        if (!rl.w.isAirBlock(rl.pos)) return;
        if (rl.state.getBlock().canPlaceBlockAt(rl.w, rl.pos)) rl.w.setBlockState(rl.pos, rl.state);
        else Block.spawnAsEntity(rl.w, rl.pos, new ItemStack(Blocks.TORCH));
    }

    public static void relightAll() {
        for (Relight rl : RELIGHTS) relight(rl);
        RELIGHTS.clear();
    }

    // ---- doors ----------------------------------------------------------------------------
    public static void toggleDoor(EntityPlayerMP p) {
        WorldServer w = (WorldServer) p.worldObj;
        BlockPos c = new BlockPos(p);
        List<BlockPos> doors = new ArrayList<BlockPos>();
        for (int x = -7; x <= 7; x++)
            for (int y = -2; y <= 2; y++)
                for (int z = -7; z <= 7; z++) {
                    BlockPos b = c.add(x, y, z);
                    IBlockState s = w.getBlockState(b);
                    if (s.getBlock() instanceof BlockDoor && s.getMaterial() == Material.WOOD
                            && s.getValue(BlockDoor.HALF) == BlockDoor.EnumDoorHalf.LOWER) doors.add(b);
                }
        if (doors.isEmpty()) return;
        BlockPos b = doors.get(RAND.nextInt(doors.size()));
        boolean open = BlockDoor.isOpen(w, b);
        ((BlockDoor) w.getBlockState(b).getBlock()).toggleDoor(w, b, !open);
    }

    // ---- theft: ordinary items only, always recoverable -----------------------------------
    private static boolean stealable(ItemStack s) {
        if (s == null || s.getMaxStackSize() == 1 || s.isItemStackDamageable() || s.isItemEnchanted() || s.hasDisplayName()) return false;
        Item it = s.getItem();
        if (it.getRegistryName() != null && it.getRegistryName().getResourceDomain().equals(SpoiledSeed.MODID)) return false;   // never quest items
        return it != Items.DIAMOND && it != Items.EMERALD && it != Items.NETHER_STAR && it != Items.WRITTEN_BOOK;
    }

    public static void steal(EntityPlayerMP p) {
        List<Integer> slots = new ArrayList<Integer>();
        for (int i = 0; i < p.inventory.mainInventory.length; i++) {
            if (stealable(p.inventory.mainInventory[i])) slots.add(Integer.valueOf(i));
        }
        if (slots.isEmpty()) return;
        WorldServer w = (WorldServer) p.worldObj;
        BlockPos spot = SpawnHelper.findSpot(w, new BlockPos(p), p, 14, 28, false);
        if (spot == null) return;                                       // no hiding place -> nothing is taken
        int slot = slots.get(RAND.nextInt(slots.size())).intValue();
        ItemStack stack = p.inventory.mainInventory[slot];
        ItemStack taken = stack.splitStack(Math.min(stack.stackSize, 1 + RAND.nextInt(3)));
        if (stack.stackSize <= 0) p.inventory.mainInventory[slot] = null;
        p.inventoryContainer.detectAndSendChanges();

        w.setBlockState(spot, Blocks.CHEST.getDefaultState());
        TileEntity te = w.getTileEntity(spot);
        if (te instanceof TileEntityChest) ((TileEntityChest) te).setInventorySlotContents(13, taken);
        else Block.spawnAsEntity(w, spot, taken);

        double dx = spot.getX() - p.posX, dz = spot.getZ() - p.posZ;
        String dir = Math.abs(dx) > Math.abs(dz) ? (dx > 0 ? "east" : "west") : (dz > 0 ? "south" : "north");
        HorrorDirector.msg(p, "Something took a few of your things. You feel they were left to the " + dir + ", hidden above ground.");
    }
}
