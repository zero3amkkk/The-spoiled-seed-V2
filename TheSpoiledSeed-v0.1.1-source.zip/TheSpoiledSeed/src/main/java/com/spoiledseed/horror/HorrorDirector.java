package com.spoiledseed.horror;

import com.spoiledseed.config.ModConfig;
import com.spoiledseed.entity.EntityNull;
import com.spoiledseed.entity.NullState;
import com.spoiledseed.quest.FinalRitual;
import com.spoiledseed.quest.QuestData;
import com.spoiledseed.quest.QuestManager;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.WorldServer;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.relauncher.Side;

/**
 * Decides WHEN things happen to each player (once per second). Order of work every second:
 * quests -> fog (independent of the monster) -> ritual / existing monster -> grace time -> cooldown -> pick an event.
 */
public class HorrorDirector {
    public static final Random RAND = new Random();
    private static final Map<UUID, PlayerHorror> PLAYERS = new HashMap<UUID, PlayerHorror>();

    public static PlayerHorror rec(EntityPlayer p) {
        PlayerHorror r = PLAYERS.get(p.getUniqueID());
        if (r == null) { r = new PlayerHorror(); PLAYERS.put(p.getUniqueID(), r); }
        return r;
    }

    public static void reset() {
        PLAYERS.clear();
        Scheduler.clear();
        FinalRitual.clearAll();
    }

    public static void msg(EntityPlayer p, String s) {
        p.addChatMessage(new TextComponentString(TextFormatting.DARK_GRAY + "" + TextFormatting.ITALIC + s));
    }

    // ---- Forge events ---------------------------------------------------------------------
    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.side != Side.SERVER || !(e.player instanceof EntityPlayerMP)) return;
        if (e.player.ticksExisted % 20 != 0) return;
        try {
            secondTick((EntityPlayerMP) e.player);
        } catch (RuntimeException ex) {
            ex.printStackTrace();           // a horror bug must never crash the server
        }
    }

    @SubscribeEvent
    public void onServerTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Scheduler.tick();
        WorldPranks.tick();
    }

    @SubscribeEvent
    public void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        if (e.player instanceof EntityPlayerMP) FinalRitual.cancel((EntityPlayerMP) e.player, null);
        PLAYERS.remove(e.player.getUniqueID());
    }

    @SubscribeEvent
    public void onDeath(LivingDeathEvent e) {
        if (!(e.getEntityLiving() instanceof EntityPlayerMP)) return;
        EntityPlayerMP p = (EntityPlayerMP) e.getEntityLiving();
        FinalRitual.cancel(p, "The altar goes dark.");
        PlayerHorror r = PLAYERS.get(p.getUniqueID());
        if (r != null) { r.pending = null; r.cooldown = Math.max(r.cooldown, 60); }
    }

    // ---- main loop ------------------------------------------------------------------------
    private void secondTick(EntityPlayerMP p) {
        QuestData.addSeconds(p, 1);
        PlayerHorror r = rec(p);
        if (p.dimension != 0 || p.isDead) { FogController.send(p, r, 0F); return; }

        QuestManager.tick(p);
        if (r.jumpCd > 0) r.jumpCd--;
        if (QuestData.isSealed(p)) { FogController.send(p, r, 0F); return; }

        WorldServer w = (WorldServer) p.worldObj;
        EntityNull n = findNull(w, r);
        float intensity = intensity(p);

        FogController.second(p, r, n, intensity);          // the fog never depends on the monster
        if (n == null && r.nullId != null) {               // it vanished -> cooldown before it can return
            r.nullId = null;
            r.cooldown = Math.max(r.cooldown, nextCooldown(intensity));
        }

        if (!ModConfig.affectCreative && (p.capabilities.isCreativeMode || p.isSpectator())) return;
        if (FinalRitual.isActive(p)) { FinalRitual.tick(p, n); return; }
        if (n != null) return;
        if (QuestData.getSeconds(p) < ModConfig.graceSeconds) return;

        if (r.pending != null) {                           // event waiting behind a fog prelude
            if (--r.pendingDelay <= 0) { HorrorEvent e = r.pending; r.pending = null; run(p, e, false); }
            return;
        }
        if (r.cooldown > 0) { r.cooldown--; return; }
        if (RAND.nextFloat() > ModConfig.eventProbability) { r.cooldown = 20 + RAND.nextInt(25); return; }

        HorrorEvent ev = pick(p, intensity);
        if (ModConfig.fogEnabled && ev.spawnsNull() && RAND.nextFloat() < ModConfig.fogBeforeEncounterChance) {
            r.pending = ev;                                // fog first, monster 8 s later
            r.pendingDelay = 8;
            r.fogPrelude = 1F;
        } else {
            run(p, ev, false);
        }
        r.cooldown = nextCooldown(intensity);
    }

    /** 0..1, grows with play time and quest stage. */
    public static float intensity(EntityPlayer p) {
        float t = Math.min(1F, QuestData.getSeconds(p) / 7200F);
        return Math.min(1F, 0.1F + QuestData.getStage(p) * 0.18F + t * 0.3F);
    }

    private static int nextCooldown(float intensity) {
        double base = ModConfig.eventIntervalSeconds * (0.6D + RAND.nextDouble() * 0.8D);
        return (int) (base / (1.0D + 2.0D * intensity)) + 15;
    }

    private static HorrorEvent pick(EntityPlayer p, float intensity) {
        int stage = QuestData.getStage(p);
        if (stage == 0 && QuestData.getSeconds(p) > ModConfig.graceSeconds + 900) return HorrorEvent.CHASE;   // guarantees the first encounter
        Map<HorrorEvent, Integer> w = new EnumMap<HorrorEvent, Integer>(HorrorEvent.class);
        w.put(HorrorEvent.OBSERVE, 5);
        w.put(HorrorEvent.GLIMPSE, 3);
        w.put(HorrorEvent.FOOTSTEPS, 3);
        w.put(HorrorEvent.SOUND, 3);
        w.put(HorrorEvent.KNOCK, 2);
        w.put(HorrorEvent.WHISPER, 2);
        w.put(HorrorEvent.TORCH, 2);
        w.put(HorrorEvent.DOOR, 2);
        if (stage >= 1) {
            w.put(HorrorEvent.STALK, 3 + stage);
            w.put(HorrorEvent.BED, 2);
            w.put(HorrorEvent.THEFT, ModConfig.theftEnabled ? 2 : 0);
            w.put(HorrorEvent.JUMPSCARE, ModConfig.jumpscareEnabled ? 2 + stage / 2 : 0);
            w.put(HorrorEvent.CHASE, 2 + stage);
        } else if (intensity > 0.3F) {
            w.put(HorrorEvent.STALK, 2);
        }
        int total = 0;
        for (int v : w.values()) total += v;
        int roll = RAND.nextInt(Math.max(1, total));
        for (Map.Entry<HorrorEvent, Integer> en : w.entrySet()) {
            roll -= en.getValue().intValue();
            if (roll < 0) return en.getKey();
        }
        return HorrorEvent.OBSERVE;
    }

    // ---- executing events (also used by /ss) -----------------------------------------------
    /** force = ignore cooldowns and replace any monster already present (used by commands). */
    public static void run(EntityPlayerMP p, HorrorEvent e, boolean force) {
        PlayerHorror r = rec(p);
        float in = intensity(p);
        if (force && (e.spawnsNull() || e == HorrorEvent.JUMPSCARE)) {
            clearNull(p);
            r.pending = null;
        }
        switch (e) {
            case OBSERVE:
                SpawnHelper.spawn(p, r, NullState.OBSERVING, 22, 36, 20 * (25 + RAND.nextInt(30)), false, 0F, true);
                break;
            case GLIMPSE:
                SpawnHelper.spawn(p, r, NullState.OBSERVING, 12, 22, 80, false, 0F, true);
                break;
            case STALK:
                SpawnHelper.spawn(p, r, NullState.STALKING, 24, 34, 20 * 40, false, 0.2F + 0.4F * in, true);
                break;
            case CHASE:
                SpawnHelper.spawn(p, r, NullState.CHASE, 16, 26, 0, false, 0F, false);
                break;
            case BED:
                spawnNearBed(p, r);
                break;
            case JUMPSCARE:
                Jumpscare.trigger(p, r, force);
                break;
            case FOOTSTEPS:
                WorldPranks.footsteps(p);
                break;
            case KNOCK:
                WorldPranks.knock(p);
                break;
            case WHISPER:
                WorldPranks.whisper(p);
                break;
            case SOUND:
                WorldPranks.distantSound(p);
                break;
            case TORCH:
                WorldPranks.extinguish(p);
                lurk(p, r);
                break;
            case DOOR:
                WorldPranks.toggleDoor(p);
                lurk(p, r);
                break;
            case THEFT:
                WorldPranks.steal(p);
                lurk(p, r);
                break;
        }
    }

    /** DISTURBANCE: sometimes it stands in the distance while it interferes with the world. */
    private static void lurk(EntityPlayerMP p, PlayerHorror r) {
        if (RAND.nextFloat() < 0.5F) SpawnHelper.spawn(p, r, NullState.DISTURBANCE, 14, 22, 200, false, 0F, true);
    }

    private static void spawnNearBed(EntityPlayerMP p, PlayerHorror r) {
        WorldServer w = (WorldServer) p.worldObj;
        net.minecraft.util.math.BlockPos bed = p.getBedLocation();
        net.minecraft.util.math.BlockPos pos = null;
        if (bed != null && bed.distanceSq(p.posX, p.posY, p.posZ) < 64 * 64) pos = SpawnHelper.standingSpotAround(w, bed, 4, 7, null);
        if (pos == null || findNull(w, r) != null) {
            SpawnHelper.spawn(p, r, NullState.OBSERVING, 14, 22, 120, false, 0F, true);
            return;
        }
        SpawnHelper.spawnAt(p, r, pos, NullState.OBSERVING, 120, false, 0F);
    }

    // ---- monster bookkeeping ---------------------------------------------------------------
    public static EntityNull findNull(WorldServer w, PlayerHorror r) {
        if (r.nullId == null) return null;
        Entity e = w.getEntityFromUuid(r.nullId);
        return (e instanceof EntityNull && !e.isDead) ? (EntityNull) e : null;
    }

    /** Removes the player's monster instantly (no vanish effect). */
    public static void clearNull(EntityPlayerMP p) {
        PlayerHorror r = rec(p);
        EntityNull n = findNull((WorldServer) p.worldObj, r);
        if (n != null) n.setDead();
        r.nullId = null;
    }
}
