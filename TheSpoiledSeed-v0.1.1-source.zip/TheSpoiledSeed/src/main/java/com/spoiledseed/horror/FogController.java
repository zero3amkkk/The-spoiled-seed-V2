package com.spoiledseed.horror;

import com.spoiledseed.config.ModConfig;
import com.spoiledseed.entity.EntityNull;
import com.spoiledseed.network.NetworkHandler;
import com.spoiledseed.network.PacketFx;
import java.util.Random;
import net.minecraft.entity.player.EntityPlayerMP;

/**
 * The Black Fog is part of the world: it comes in natural episodes by itself, also before encounters,
 * after scares, and gets thicker when The Null is near. It never REQUIRES the monster.
 */
public class FogController {
    private static final Random RAND = new Random();

    public static void second(EntityPlayerMP p, PlayerHorror r, EntityNull n, float intensity) {
        float fog = r.fogPrelude;
        r.fogPrelude = Math.max(0F, r.fogPrelude - 0.05F);

        if (r.episodeLeft > 0) {
            r.episodeLeft--;
            fog = Math.max(fog, r.episodeLevel);
        } else if (ModConfig.fogEnabled && RAND.nextFloat() < ModConfig.fogEpisodeChance * (1F + 2F * intensity)) {
            r.episodeLeft = 60 + RAND.nextInt(100);                 // 1 - 2.7 minutes
            r.episodeLevel = 0.25F + RAND.nextFloat() * 0.45F;
        }
        if (n != null) {
            float d = (float) n.getDistanceToEntity(p);
            fog = Math.max(fog, 0.25F + 0.75F * Math.max(0F, 1F - d / 45F));
        }
        if (r.fogForce >= 0F) fog = r.fogForce;                      // /ss fog <n>
        else if (!ModConfig.fogEnabled) fog = 0F;
        send(p, r, fog);
    }

    public static void send(EntityPlayerMP p, PlayerHorror r, float f) {
        f = Math.max(0F, Math.min(1F, f));
        if (Math.abs(f - r.lastFogSent) > 0.03F) {
            r.lastFogSent = f;
            NetworkHandler.CHANNEL.sendTo(new PacketFx(PacketFx.FOG, f), p);
        }
    }

    public static void sendNow(EntityPlayerMP p, PlayerHorror r, float f) {
        r.lastFogSent = -1F;
        send(p, r, f);
    }
}
