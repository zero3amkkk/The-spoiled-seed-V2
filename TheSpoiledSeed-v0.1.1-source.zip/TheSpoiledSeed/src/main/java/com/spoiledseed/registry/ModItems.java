package com.spoiledseed.registry;

import com.spoiledseed.SpoiledSeed;
import com.spoiledseed.item.ItemLore;
import com.spoiledseed.item.ItemNullSeal;
import net.minecraft.item.Item;
import net.minecraftforge.fml.common.registry.GameRegistry;

/** Quest items. IDs: corrupted_sample, relic_*, journal_*, null_seal. */
public class ModItems {
    public static Item corruptedSample, relicEcho, relicCore, relicSeal, journalTorn, journalAncient, nullSeal;

    public static void register() {
        corruptedSample = reg(new ItemLore("A shard of dead bark. Cold, and it does not rot.",
                "Three of these, from three scars in the earth, would tell a story."), "corrupted_sample");
        relicEcho = reg(new ItemLore("A shard of crystal. Held to your ear, it repeats your footsteps - a moment late."), "relic_echo_fragment");
        relicCore = reg(new ItemLore("A black heart that beats once a minute. The fog leans toward it."), "relic_corrupted_core");
        relicSeal = reg(new ItemLore("A stone disc worn smooth by hands that no longer exist."), "relic_forgotten_seal");
        journalTorn = reg(new ItemLore(
                "\"It watches from the trees. It never blinks.\"",
                "\"When the fog comes, it is already close. Do not look too long. Do not run until you must.\"",
                "\"I found places where the ground is dead - black sand ringed with moss-stone. Whatever it is, it grows from there. Find three. Bring back what they hide.\""), "journal_torn");
        journalAncient = reg(new ItemLore(
                "\"The Seal was made in three parts: an Echo, a voice that would not fade; a Core, the heart of the corruption; and a Seal, the promise of those who bound it.\"",
                "\"Join the three. Bring the result to an Altar. Charge it three times while The Null walks - and do not leave the Altar, or the binding fails.\"",
                "\"It is not a weapon. It is a door, and The Null must be walked through it.\""), "journal_ancient");
        nullSeal = reg(new ItemNullSeal(), "null_seal");
    }

    private static Item reg(Item item, String name) {
        item.setRegistryName(SpoiledSeed.MODID, name);
        item.setUnlocalizedName(name);
        item.setCreativeTab(ModTab.TAB);
        GameRegistry.register(item);
        return item;
    }
}
