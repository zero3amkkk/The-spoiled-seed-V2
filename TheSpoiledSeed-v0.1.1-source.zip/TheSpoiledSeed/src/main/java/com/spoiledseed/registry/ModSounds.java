package com.spoiledseed.registry;

import com.spoiledseed.SpoiledSeed;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;

/** Sound events. Files live in assets/spoiledseed/sounds/** and are mapped in sounds.json. */
public class ModSounds {
    public static SoundEvent JUMPSCARE, FOOTSTEP, CHASE_STEP, VANISH, HEARTBEAT, WHISPER, BREATH, KNOCK, SCRAPE, DRONE, SEAL;

    public static void register() {
        JUMPSCARE = make("null.jumpscare");     // TPS S
        FOOTSTEP = make("null.footstep");
        CHASE_STEP = make("null.chase");
        VANISH = make("null.vanish");
        HEARTBEAT = make("null.heartbeat");
        WHISPER = make("null.whisper");
        BREATH = make("null.breath");
        KNOCK = make("null.knock");
        SCRAPE = make("null.scrape");
        DRONE = make("ambient.drone");
        SEAL = make("seal.activate");
    }

    private static SoundEvent make(String name) {
        ResourceLocation rl = new ResourceLocation(SpoiledSeed.MODID, name);
        SoundEvent s = new SoundEvent(rl);
        s.setRegistryName(rl);
        GameRegistry.register(s);
        return s;
    }
}
