package com.spoiledseed.client;

import com.spoiledseed.network.PacketFx;
import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

/** Client-side effect state, written by packets and read by the handlers. */
public class ClientFx {
    public static final int JUMP_LEN = 40;
    public static final int ENDING_LEN = 520;

    public static float fogTarget, fogCurrent;
    public static int jumpTicks, jumpVariant;
    public static int endingTick = -1;

    public static void handle(int type, float value) {
        if (type == PacketFx.FOG) fogTarget = value;
        else if (type == PacketFx.JUMPSCARE) { jumpTicks = JUMP_LEN; jumpVariant = (int) value; }
        else if (type == PacketFx.ENDING) endingTick = 0;
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        if (Minecraft.getMinecraft().theWorld == null) {       // left the world
            fogTarget = 0F; fogCurrent = 0F; jumpTicks = 0; endingTick = -1;
            return;
        }
        fogCurrent += (fogTarget - fogCurrent) * 0.03F;
        if (Math.abs(fogTarget - fogCurrent) < 0.002F) fogCurrent = fogTarget;
        if (jumpTicks > 0) jumpTicks--;
        if (endingTick >= 0 && ++endingTick > ENDING_LEN) endingTick = -1;
    }
}
