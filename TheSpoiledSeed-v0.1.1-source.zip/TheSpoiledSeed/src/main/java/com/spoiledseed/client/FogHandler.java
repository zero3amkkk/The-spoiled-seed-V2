package com.spoiledseed.client;

import net.minecraft.client.renderer.GlStateManager;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/** Black Fog: plain GL fog (no shaders), darkened fog colour. */
public class FogHandler {
    @SubscribeEvent
    public void onFog(EntityViewRenderEvent.RenderFogEvent e) {
        float f = ClientFx.fogCurrent;
        if (f <= 0.01F) return;
        float end = Math.max(6F, e.getFarPlaneDistance() * (1F - 0.88F * f));
        GlStateManager.setFog(GlStateManager.FogMode.LINEAR);
        GlStateManager.setFogStart(end * 0.05F);
        GlStateManager.setFogEnd(end);
    }

    @SubscribeEvent
    public void onFogColor(EntityViewRenderEvent.FogColors e) {
        float f = ClientFx.fogCurrent;
        if (f <= 0.01F) return;
        float k = 1F - 0.92F * f;
        e.setRed(e.getRed() * k);
        e.setGreen(e.getGreen() * k);
        e.setBlue(e.getBlue() * k);
    }
}
