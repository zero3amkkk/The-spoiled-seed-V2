package com.spoiledseed.client;

import com.spoiledseed.entity.EntityNull;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.layers.LayerRenderer;
import net.minecraft.util.math.MathHelper;

/** Pulsing black halo: two translucent black shells of the model, slightly bigger than the body. */
public class LayerNullAura implements LayerRenderer<EntityNull> {
    private final RenderNull renderer;

    public LayerNullAura(RenderNull renderer) { this.renderer = renderer; }

    @Override
    public void doRenderLayer(EntityNull e, float limbSwing, float limbSwingAmount, float partialTicks,
                              float age, float netHeadYaw, float headPitch, float scale) {
        float a = e.getAlpha();
        if (a < 0.05F) return;
        this.renderer.bindTexture(RenderNull.SKIN);
        GlStateManager.enableBlend();
        GlStateManager.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
        GlStateManager.depthMask(false);
        float pulse = MathHelper.sin(age * 0.12F);
        float[] sizes = { 1.09F + 0.02F * pulse, 1.20F + 0.04F * pulse };
        float[] alphas = { 0.45F, 0.20F };
        for (int i = 0; i < sizes.length; i++) {
            float s = sizes[i];
            GlStateManager.pushMatrix();
            GlStateManager.translate(0F, 1.5F * (1F - s), 0F);      // scale around the feet, not the shoulders
            GlStateManager.scale(s, s, s);
            GlStateManager.color(0F, 0F, 0F, alphas[i] * a);
            this.renderer.getMainModel().render(e, limbSwing, limbSwingAmount, age, netHeadYaw, headPitch, scale);
            GlStateManager.popMatrix();
        }
        GlStateManager.depthMask(true);
        GlStateManager.color(1F, 1F, 1F, 1F);
    }

    @Override
    public boolean shouldCombineTextures() { return false; }
}
