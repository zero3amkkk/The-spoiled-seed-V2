package com.spoiledseed;

import com.spoiledseed.command.CommandSS;
import com.spoiledseed.config.ModConfig;
import com.spoiledseed.entity.EntityNull;
import com.spoiledseed.guide.GuideHandler;
import com.spoiledseed.horror.HorrorDirector;
import com.spoiledseed.horror.WorldPranks;
import com.spoiledseed.network.NetworkHandler;
import com.spoiledseed.proxy.CommonProxy;
import com.spoiledseed.quest.QuestManager;
import com.spoiledseed.registry.ModBlocks;
import com.spoiledseed.registry.ModItems;
import com.spoiledseed.registry.ModRecipes;
import com.spoiledseed.registry.ModSounds;
import com.spoiledseed.world.StructureGenerator;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.event.FMLServerStartingEvent;
import net.minecraftforge.fml.common.event.FMLServerStoppingEvent;
import net.minecraftforge.fml.common.registry.EntityRegistry;
import net.minecraftforge.fml.common.registry.GameRegistry;

@Mod(modid = SpoiledSeed.MODID, name = "The Spoiled Seed", version = SpoiledSeed.VERSION, acceptedMinecraftVersions = "[1.9.4]")
public class SpoiledSeed {
    public static final String MODID = "spoiledseed";
    public static final String VERSION = "0.1.1";

    @Mod.Instance(MODID)
    public static SpoiledSeed instance;

    @SidedProxy(clientSide = "com.spoiledseed.proxy.ClientProxy", serverSide = "com.spoiledseed.proxy.CommonProxy")
    public static CommonProxy proxy;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent e) {
        ModConfig.load(e.getSuggestedConfigurationFile());
        ModSounds.register();
        ModItems.register();
        ModBlocks.register();
        NetworkHandler.init();
        EntityRegistry.registerModEntity(EntityNull.class, "the_null", 0, this, 64, 3, true);
        MinecraftForge.EVENT_BUS.register(new HorrorDirector());
        MinecraftForge.EVENT_BUS.register(new QuestManager());
        MinecraftForge.EVENT_BUS.register(new GuideHandler());
        proxy.preInit();
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent e) {
        ModRecipes.register();
        GameRegistry.registerWorldGenerator(new StructureGenerator(), 0);
        proxy.init();
    }

    @Mod.EventHandler
    public void serverStarting(FMLServerStartingEvent e) {
        HorrorDirector.reset();
        e.registerServerCommand(new CommandSS());
    }

    @Mod.EventHandler
    public void serverStopping(FMLServerStoppingEvent e) {
        WorldPranks.relightAll();
        HorrorDirector.reset();
    }
}
