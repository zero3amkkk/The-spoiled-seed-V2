package com.spoiledseed.config;

import java.io.File;
import net.minecraftforge.common.config.Configuration;

public class ModConfig {
    // timing
    public static int graceSeconds = 600;
    public static int eventIntervalSeconds = 180;
    public static int jumpscareCooldownSeconds = 300;
    // gameplay
    public static float eventProbability = 0.7F;
    public static int chaseDurationSeconds = 25;
    public static float chaseSpeed = 0.31F;
    public static float chaseDamage = 3.0F;
    public static boolean jumpscareEnabled = true;
    public static boolean theftEnabled = true;
    public static boolean affectCreative = false;
    // fog
    public static boolean fogEnabled = true;
    public static float fogEpisodeChance = 0.004F;
    public static float fogBeforeEncounterChance = 0.4F;
    // world
    public static boolean structuresEnabled = true;
    public static int structureRegionChunks = 10;
    // convenience
    public static boolean openCommands = true;
    public static boolean giveGuideBook = true;

    public static void load(File file) {
        Configuration c = new Configuration(file);
        String t = "timing";
        graceSeconds = c.getInt("graceSeconds", t, graceSeconds, 0, 1000000, "Seconds of play before the monster's events can start (per player).");
        eventIntervalSeconds = c.getInt("eventIntervalSeconds", t, eventIntervalSeconds, 20, 100000, "Base seconds between events. Shrinks as the story progresses.");
        jumpscareCooldownSeconds = c.getInt("jumpscareCooldownSeconds", t, jumpscareCooldownSeconds, 10, 100000, "Minimum seconds between NATURAL jumpscares (commands ignore it).");
        String g = "gameplay";
        eventProbability = c.getFloat("eventProbability", g, eventProbability, 0F, 1F, "Chance that an event fires when its timer expires.");
        chaseDurationSeconds = c.getInt("chaseDurationSeconds", g, chaseDurationSeconds, 5, 600, "Average chase length in seconds.");
        chaseSpeed = c.getFloat("chaseSpeed", g, chaseSpeed, 0.1F, 0.6F, "Movement speed of The Null while chasing.");
        chaseDamage = c.getFloat("chaseDamage", g, chaseDamage, 0F, 20F, "Damage per hit (2.0 = one heart).");
        jumpscareEnabled = c.getBoolean("jumpscareEnabled", g, jumpscareEnabled, "Allow natural jumpscares.");
        theftEnabled = c.getBoolean("theftEnabled", g, theftEnabled, "Allow The Null to hide small amounts of ordinary items.");
        affectCreative = c.getBoolean("affectCreative", g, affectCreative, "Run monster events on creative/spectator players.");
        String f = "fog";
        fogEnabled = c.getBoolean("fogEnabled", f, fogEnabled, "Enable the Black Fog. It is part of the world and does NOT need the monster.");
        fogEpisodeChance = c.getFloat("fogEpisodeChance", f, fogEpisodeChance, 0F, 1F, "Chance per second that a fog episode starts by itself.");
        fogBeforeEncounterChance = c.getFloat("fogBeforeEncounterChance", f, fogBeforeEncounterChance, 0F, 1F, "Chance that fog rolls in seconds before an encounter.");
        String w = "world";
        structuresEnabled = c.getBoolean("structuresEnabled", w, structuresEnabled, "Generate the corrupted structures.");
        structureRegionChunks = c.getInt("structureRegionChunks", w, structureRegionChunks, 4, 32, "Every NxN-chunk region holds exactly 3 Sites, 1 Shrine, 1 Cairn and 1 Ruin.");
        String o = "convenience";
        openCommands = c.getBoolean("openCommands", o, openCommands, "true = everyone can use /ss (no cheats needed). false = operators only.");
        giveGuideBook = c.getBoolean("giveGuideBook", o, giveGuideBook, "Give the Survivor's Guide on first join and after every respawn.");
        if (c.hasChanged()) c.save();
    }
}
