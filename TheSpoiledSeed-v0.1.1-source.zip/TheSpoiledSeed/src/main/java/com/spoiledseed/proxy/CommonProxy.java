package com.spoiledseed.proxy;

public class CommonProxy {
    public void preInit() {}
    public void init() {}
    /** Client-only effects; dedicated servers ignore this. */
    public void handlePacket(int type, float value) {}
}
