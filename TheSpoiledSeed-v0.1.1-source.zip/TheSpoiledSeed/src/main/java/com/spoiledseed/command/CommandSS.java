package com.spoiledseed.command;

import com.spoiledseed.config.ModConfig;
import com.spoiledseed.guide.GuideHandler;
import com.spoiledseed.horror.FogController;
import com.spoiledseed.horror.HorrorDirector;
import com.spoiledseed.horror.HorrorEvent;
import com.spoiledseed.horror.PlayerHorror;
import com.spoiledseed.quest.QuestData;
import com.spoiledseed.registry.ModBlocks;
import com.spoiledseed.registry.ModItems;
import com.spoiledseed.world.StructureGenerator;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.command.WrongUsageException;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.util.text.event.ClickEvent;

/**
 * /ss (alias /spoiledseed). Short and cooldown-free: every event name works directly, as often as you like.
 *   /ss jumpscare | chase | stalk | observe | glimpse | bed | footsteps | knock | whisper | sound | torch | door | theft
 *   /ss fog <0-100|off>   /ss stage <0-5>   /ss locate <site|shrine|cairn|ruin>   /ss give | guide | clear | status | reset | help
 */
public class CommandSS extends CommandBase {
    @Override public String getCommandName() { return "spoiledseed"; }
    @Override public List<String> getCommandAliases() { return Arrays.asList("ss"); }
    @Override public String getCommandUsage(ICommandSender sender) { return "/ss help"; }
    @Override public int getRequiredPermissionLevel() { return ModConfig.openCommands ? 0 : 2; }

    @Override
    public List<String> getTabCompletionOptions(MinecraftServer server, ICommandSender sender, String[] args, BlockPos pos) {
        List<String> all = new ArrayList<String>();
        for (HorrorEvent e : HorrorEvent.values()) all.add(e.key);
        all.addAll(Arrays.asList("fog", "stage", "locate", "give", "guide", "clear", "status", "reset", "help"));
        if (args.length == 1) return getListOfStringsMatchingLastWord(args, all);
        if (args.length == 2 && args[0].equalsIgnoreCase("locate")) return getListOfStringsMatchingLastWord(args, "site", "shrine", "cairn", "ruin");
        if (args.length == 2 && args[0].equalsIgnoreCase("fog")) return getListOfStringsMatchingLastWord(args, "off", "30", "60", "100");
        return new ArrayList<String>();
    }

    @Override
    public void execute(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
        EntityPlayerMP p = getCommandSenderAsPlayer(sender);
        if (args.length == 0) { help(p); return; }
        String a = args[0].toLowerCase();

        HorrorEvent ev = HorrorEvent.byKey(a);
        if (ev == null && a.equals("event") && args.length > 1) ev = HorrorEvent.byKey(args[1]);   // old syntax still works
        if (ev != null) { HorrorDirector.run(p, ev, true); return; }

        if (a.equals("fog")) {
            if (args.length < 2) throw new WrongUsageException("/ss fog <0-100|off>");
            PlayerHorror r = HorrorDirector.rec(p);
            if (args[1].equalsIgnoreCase("off")) { r.fogForce = -1F; say(p, "Fog back to automatic."); }
            else { r.fogForce = parseInt(args[1], 0, 100) / 100F; say(p, "Fog fixed at " + args[1] + "%. (/ss fog off to release)"); }
            FogController.sendNow(p, r, r.fogForce >= 0F ? r.fogForce : 0F);
        } else if (a.equals("stage")) {
            if (args.length < 2) throw new WrongUsageException("/ss stage <0-5>");
            QuestData.setStage(p, parseInt(args[1], 0, 5));
            say(p, "Stage set to " + QuestData.getStage(p));
        } else if (a.equals("locate")) {
            if (args.length < 2) throw new WrongUsageException("/ss locate <site|shrine|cairn|ruin>");
            StructureGenerator.Kind k;
            try { k = StructureGenerator.Kind.valueOf(args[1].toUpperCase()); }
            catch (IllegalArgumentException ex) { throw new WrongUsageException("/ss locate <site|shrine|cairn|ruin>"); }
            StructureGenerator.Slot s = StructureGenerator.locate(p.worldObj, new BlockPos(p), k);
            if (s == null) say(p, "Nothing planned nearby.");
            else say(p, k + " planned at x=" + s.blockX() + " z=" + s.blockZ() + "  (" + (int) Math.sqrt(p.getDistanceSq(s.blockX(), p.posY, s.blockZ())) + " blocks away)");
        } else if (a.equals("give")) {
            ItemStack[] all = new ItemStack[] {
                new ItemStack(ModItems.corruptedSample, 3), new ItemStack(ModItems.relicEcho), new ItemStack(ModItems.relicCore),
                new ItemStack(ModItems.relicSeal), new ItemStack(ModItems.journalTorn), new ItemStack(ModItems.journalAncient),
                new ItemStack(ModBlocks.ancientAltar) };
            for (ItemStack s : all) if (!p.inventory.addItemStackToInventory(s)) p.entityDropItem(s, 0F);
            say(p, "Quest items given.");
        } else if (a.equals("guide")) {
            GuideHandler.give(p);
            say(p, "New Survivor's Guide given.");
        } else if (a.equals("clear")) {
            HorrorDirector.clearNull(p);
            say(p, "The Null was removed.");
        } else if (a.equals("reset")) {
            QuestData.setStage(p, 0);
            QuestData.setSealed(p, false);
            HorrorDirector.rec(p).fogForce = -1F;
            say(p, "Progress reset (play time kept).");
        } else if (a.equals("status")) {
            say(p, "stage=" + QuestData.getStage(p) + "  playtime=" + QuestData.getSeconds(p) + "s  sealed=" + QuestData.isSealed(p));
        } else {
            help(p);
        }
    }

    private static void say(EntityPlayerMP p, String s) { p.addChatMessage(new TextComponentString(s)); }

    private static ITextComponent button(String label, String cmd, TextFormatting color) {
        ITextComponent c = new TextComponentString("[" + label + "] ");
        c.getStyle().setColor(color).setClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, cmd));
        return c;
    }

    /** Clickable menu in chat. */
    private static void help(EntityPlayerMP p) {
        say(p, TextFormatting.DARK_RED + "== THE SPOILED SEED ==" + TextFormatting.RESET + "  (click a button, or type /ss <name>)");
        String[][] rows = {
            { "Jumpscare", "jumpscare", "Chase", "chase", "Stalk", "stalk", "Observe", "observe", "Glimpse", "glimpse" },
            { "Footsteps", "footsteps", "Knock", "knock", "Whisper", "whisper", "Sound", "sound", "Bed", "bed" },
            { "Torch", "torch", "Door", "door", "Theft", "theft", "Remove Null", "clear" },
            { "Fog 40", "fog 40", "Fog 100", "fog 100", "Fog off", "fog off" },
            { "Status", "status", "Quest items", "give", "Guide", "guide", "Reset", "reset" } };
        for (String[] row : rows) {
            ITextComponent line = new TextComponentString("");
            for (int i = 0; i < row.length; i += 2) line.appendSibling(button(row[i], "/ss " + row[i + 1], TextFormatting.RED));
            p.addChatMessage(line);
        }
    }
}
