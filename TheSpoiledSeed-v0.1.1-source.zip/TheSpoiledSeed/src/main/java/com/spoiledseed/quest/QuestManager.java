package com.spoiledseed.quest;

import com.spoiledseed.registry.ModItems;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent;

/**
 * The 5 main quests. QuestData.stage = number of completed quests.
 * Q1 First Sighting (survive a chase) | Q2 Black Fog (3 samples) | Q3 Forgotten Place (ancient journal)
 * Q4 Three Relics (echo + core + seal) | Q5 Final Ritual (see FinalRitual)
 */
public class QuestManager {
    public static int count(EntityPlayerMP p, Item item) {
        int n = 0;
        for (ItemStack s : p.inventory.mainInventory) if (s != null && s.getItem() == item) n += s.stackSize;
        return n;
    }

    private static void advance(EntityPlayerMP p, int stage, String text) {
        QuestData.setStage(p, stage);
        p.addChatMessage(new TextComponentString(TextFormatting.GOLD + "[Quest] " + TextFormatting.GRAY + text));
    }

    public static void tick(EntityPlayerMP p) {
        switch (QuestData.getStage(p)) {
            case 1:
                if (count(p, ModItems.corruptedSample) >= 3)
                    advance(p, 2, "THE BLACK FOG complete. Three scars, three samples. Something older lies beneath the dead ground - a Forgotten Ruin.");
                break;
            case 2:
                if (count(p, ModItems.journalAncient) >= 1)
                    advance(p, 3, "THE FORGOTTEN PLACE complete. Read the Ancient Journal. Gather the Echo Fragment, the Corrupted Core and the Forgotten Seal.");
                break;
            case 3:
                if (count(p, ModItems.relicEcho) >= 1 && count(p, ModItems.relicCore) >= 1 && count(p, ModItems.relicSeal) >= 1)
                    advance(p, 4, "THE THREE RELICS complete. Combine them into THE NULL SEAL, then take an Ancient Altar somewhere open.");
                break;
            default:
                break;
        }
    }

    /** Quest 1: called by the entity when a chase ended with the player alive. */
    public static void onChaseSurvived(EntityPlayer p) {
        if (!(p instanceof EntityPlayerMP) || QuestData.getStage(p) != 0) return;
        EntityPlayerMP mp = (EntityPlayerMP) p;
        advance(mp, 1, "THE FIRST SIGHTING complete. You survived. A torn journal lies in your pack - right-click it.");
        ItemStack j = new ItemStack(ModItems.journalTorn);
        if (!mp.inventory.addItemStackToInventory(j)) mp.entityDropItem(j, 0F);
    }

    @SubscribeEvent
    public void onCrafted(PlayerEvent.ItemCraftedEvent e) {
        if (e.crafting != null && e.crafting.getItem() == ModItems.nullSeal && !e.player.worldObj.isRemote) {
            e.player.addChatMessage(new TextComponentString(TextFormatting.GOLD + "[Quest] " + TextFormatting.GRAY
                    + "The Null Seal is whole. Take an Ancient Altar somewhere open and right-click it with the Seal."));
        }
    }
}
