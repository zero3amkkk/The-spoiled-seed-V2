package com.spoiledseed.quest;

import com.spoiledseed.horror.FogController;
import com.spoiledseed.horror.HorrorDirector;
import com.spoiledseed.horror.PlayerHorror;
import com.spoiledseed.horror.SpawnHelper;
import com.spoiledseed.entity.EntityNull;
import com.spoiledseed.network.NetworkHandler;
import com.spoiledseed.network.PacketFx;
import com.spoiledseed.registry.ModItems;
import com.spoiledseed.registry.ModSounds;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.WorldServer;

/** Quest 5 - THE FINAL RITUAL at the Ancient Altar. Kept in memory only (a restart cancels it safely). */
public class FinalRitual {
    private static class State { BlockPos altar; int clicks; long nextClick; }

    private static final Map<UUID, State> ACTIVE = new HashMap<UUID, State>();
    private static final int CLICKS_NEEDED = 3;
    private static final int CHARGE_TICKS = 160;

    public static void clearAll() { ACTIVE.clear(); }
    public static boolean isActive(EntityPlayerMP p) { return ACTIVE.containsKey(p.getUniqueID()); }

    public static void onAltarUse(EntityPlayerMP p, BlockPos pos, ItemStack held) {
        WorldServer w = (WorldServer) p.worldObj;
        if (QuestData.isSealed(p)) { HorrorDirector.msg(p, "The altar is silent. There is nothing left to seal."); return; }
        if (held == null || held.getItem() != ModItems.nullSeal) {
            HorrorDirector.msg(p, "A circular hollow waits on the altar. It needs THE NULL SEAL.");
            return;
        }
        State st = ACTIVE.get(p.getUniqueID());
        long now = w.getTotalWorldTime();
        if (st == null) {
            st = new State();
            st.altar = pos;
            st.nextClick = now + 100;
            ACTIVE.put(p.getUniqueID(), st);
            HorrorDirector.msg(p, "The altar awakens. THE NULL is coming. Charge the seal " + CLICKS_NEEDED
                    + " times (right-click the altar, once every ~8 seconds) - and do not leave.");
            w.playSound(null, pos.getX(), pos.getY(), pos.getZ(), ModSounds.SEAL, SoundCategory.BLOCKS, 2F, 0.6F);
            HorrorDirector.rec(p).fogPrelude = 1F;
            SpawnHelper.spawnRitualNull(p);
            return;
        }
        if (now < st.nextClick) { HorrorDirector.msg(p, "The seal is still gathering strength..."); return; }
        st.clicks++;
        st.nextClick = now + CHARGE_TICKS;
        w.spawnParticle(EnumParticleTypes.END_ROD, pos.getX() + 0.5D, pos.getY() + 1.2D, pos.getZ() + 0.5D, 25, 0.4D, 0.5D, 0.4D, 0.03D);
        w.playSound(null, pos.getX(), pos.getY(), pos.getZ(), ModSounds.SEAL, SoundCategory.BLOCKS, 1.5F, 0.8F + st.clicks * 0.2F);
        if (st.clicks >= CLICKS_NEEDED) complete(p, st);
        else HorrorDirector.msg(p, "The seal hums (" + st.clicks + "/" + CLICKS_NEEDED + "). Survive.");
    }

    /** Called every second by the director while the ritual runs. */
    public static void tick(EntityPlayerMP p, EntityNull n) {
        State st = ACTIVE.get(p.getUniqueID());
        if (st == null) return;
        HorrorDirector.rec(p).fogPrelude = 1F;
        if (p.getDistanceSq(st.altar) > 48D * 48D) { cancel(p, "You left the altar. The seal's light fades."); return; }
        if (n == null) SpawnHelper.spawnRitualNull(p);       // keeps the encounter alive if it was lost
    }

    public static void cancel(EntityPlayerMP p, String why) {
        if (ACTIVE.remove(p.getUniqueID()) == null) return;
        if (why != null) HorrorDirector.msg(p, why);
        PlayerHorror r = HorrorDirector.rec(p);
        EntityNull n = HorrorDirector.findNull((WorldServer) p.worldObj, r);
        if (n != null) n.sealAway();
        r.cooldown = Math.max(r.cooldown, 120);
    }

    private static void complete(EntityPlayerMP p, State st) {
        ACTIVE.remove(p.getUniqueID());
        ItemStack held = p.getHeldItemMainhand();
        if (held != null) {
            held.stackSize--;
            if (held.stackSize <= 0) p.setHeldItem(EnumHand.MAIN_HAND, null);
        }
        WorldServer w = (WorldServer) p.worldObj;
        EntityNull n = HorrorDirector.findNull(w, HorrorDirector.rec(p));
        if (n != null) n.sealAway();                                     // trapped and removed from the world
        BlockPos a = st.altar;
        w.playSound(null, a.getX(), a.getY(), a.getZ(), ModSounds.SEAL, SoundCategory.BLOCKS, 3F, 0.5F);
        w.spawnParticle(EnumParticleTypes.END_ROD, a.getX() + 0.5D, a.getY() + 1.2D, a.getZ() + 0.5D, 80, 0.6D, 0.9D, 0.6D, 0.06D);

        QuestData.setStage(p, 5);
        MinecraftServer server = p.getServer();
        List<EntityPlayerMP> all = server != null ? server.getPlayerList().getPlayerList() : null;
        if (all != null) for (EntityPlayerMP q : all) finish(q); else finish(p);
    }

    /** Saves the ending flag, clears fog, shows the ending text. Sealed players never get events again. */
    private static void finish(EntityPlayerMP q) {
        QuestData.setSealed(q, true);
        PlayerHorror r = HorrorDirector.rec(q);
        r.fogPrelude = 0F;
        r.episodeLeft = 0;
        r.fogForce = -1F;
        r.pending = null;
        FogController.sendNow(q, r, 0F);
        NetworkHandler.CHANNEL.sendTo(new PacketFx(PacketFx.ENDING, 0F), q);
    }
}
