package com.spoiledseed.quest;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;

/** Per-player progress in Forge's persisted NBT (survives death and restarts). */
public class QuestData {
    public static NBTTagCompound get(EntityPlayer p) {
        NBTTagCompound root = p.getEntityData();
        if (!root.hasKey(EntityPlayer.PERSISTED_NBT_TAG)) root.setTag(EntityPlayer.PERSISTED_NBT_TAG, new NBTTagCompound());
        NBTTagCompound pers = root.getCompoundTag(EntityPlayer.PERSISTED_NBT_TAG);
        if (!pers.hasKey("SpoiledSeed")) pers.setTag("SpoiledSeed", new NBTTagCompound());
        return pers.getCompoundTag("SpoiledSeed");
    }

    /** Completed main quests (0..5). 5 = finished. */
    public static int getStage(EntityPlayer p) { return get(p).getInteger("Stage"); }
    public static void setStage(EntityPlayer p, int v) { get(p).setInteger("Stage", v); }
    public static int getSeconds(EntityPlayer p) { return get(p).getInteger("Seconds"); }
    public static void addSeconds(EntityPlayer p, int n) { get(p).setInteger("Seconds", getSeconds(p) + n); }
    public static boolean isSealed(EntityPlayer p) { return get(p).getBoolean("Sealed"); }
    public static void setSealed(EntityPlayer p, boolean v) { get(p).setBoolean("Sealed", v); }
    public static boolean isGuideGiven(EntityPlayer p) { return get(p).getBoolean("GuideGiven"); }
    public static void setGuideGiven(EntityPlayer p, boolean v) { get(p).setBoolean("GuideGiven", v); }
}
