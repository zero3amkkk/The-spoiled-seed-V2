package com.spoiledseed.entity;

import com.spoiledseed.config.ModConfig;
import com.spoiledseed.quest.QuestData;
import com.spoiledseed.quest.QuestManager;
import com.spoiledseed.registry.ModSounds;
import java.util.UUID;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.pathfinding.PathNavigateGround;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

/**
 * THE NULL. Gameplay runs server-side in updateAITasks(); the client reads two synced values:
 * STATE (for logic/visuals) and ALPHA (fade in / fade out so it blends into the scene).
 * It owns no persistent data: without an owner player it removes itself (no duplicates after reload).
 */
public class EntityNull extends EntityCreature {
    private static final DataParameter<Integer> STATE = EntityDataManager.<Integer>createKey(EntityNull.class, DataSerializers.VARINT);
    private static final DataParameter<Float> ALPHA = EntityDataManager.<Float>createKey(EntityNull.class, DataSerializers.FLOAT);

    public static final int FADE_IN_TICKS = 30;
    public static final int VANISH_TICKS = 18;

    private UUID ownerId;
    private int stateTicks, lifeTicks, maxLife = 600, lookedTicks, attackCooldown, searchTicks, chaseTicksLeft;
    private float escalateChance, lastAlpha = -1F;
    private boolean ritual;
    private BlockPos lastKnown;

    public EntityNull(World world) {
        super(world);
        this.setSize(0.6F, 1.8F);
        this.isImmuneToFire = true;
        this.tasks.addTask(0, new EntityAISwimming(this));
        ((PathNavigateGround) this.getNavigator()).setCanSwim(true);
    }

    @Override
    protected void entityInit() {
        super.entityInit();
        this.dataManager.register(STATE, Integer.valueOf(0));
        this.dataManager.register(ALPHA, Float.valueOf(0F));
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        this.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(40.0D);
        this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(0.23D);
        this.getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE).setBaseValue(64.0D);
        this.getAttributeMap().registerAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).setBaseValue(3.0D);
    }

    @Override
    protected boolean canDespawn() { return false; }

    // ---- synced values ------------------------------------------------------------------
    public NullState getState() { return NullState.byId(this.dataManager.get(STATE).intValue()); }
    public float getAlpha() { return this.dataManager.get(ALPHA).floatValue(); }

    public void setState(NullState s) {
        this.dataManager.set(STATE, Integer.valueOf(s.ordinal()));
        this.stateTicks = 0;
        this.lookedTicks = 0;
        this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(s == NullState.CHASE ? ModConfig.chaseSpeed : 0.23D);
        if (s == NullState.CHASE) {
            this.chaseTicksLeft = (int) (ModConfig.chaseDurationSeconds * 20 * (0.8D + this.rand.nextDouble() * 0.4D));
            this.searchTicks = 0;
        }
    }

    /** Called once by SpawnHelper right after construction (server side). */
    public void init(EntityPlayer owner, NullState state, int maxLifeTicks, boolean ritualMode, float escalate) {
        this.ownerId = owner.getUniqueID();
        this.maxLife = maxLifeTicks;
        this.ritual = ritualMode;
        this.escalateChance = escalate;
        this.getAttributeMap().getAttributeInstance(SharedMonsterAttributes.ATTACK_DAMAGE).setBaseValue(ModConfig.chaseDamage);
        this.setState(state);
        this.faceEntity(owner, 360.0F, 360.0F);
        this.rotationYawHead = this.rotationYaw;
    }

    // ---- client: dark halo particles ------------------------------------------------------
    @Override
    public void onLivingUpdate() {
        super.onLivingUpdate();
        if (this.worldObj.isRemote && this.getAlpha() > 0.15F) {
            for (int i = 0; i < 2; i++) {
                this.worldObj.spawnParticle(EnumParticleTypes.SMOKE_NORMAL,
                        this.posX + (this.rand.nextDouble() - 0.5D) * 0.9D,
                        this.posY + this.rand.nextDouble() * 2.0D,
                        this.posZ + (this.rand.nextDouble() - 0.5D) * 0.9D,
                        0.0D, 0.015D, 0.0D);
            }
            if (this.rand.nextInt(3) == 0) {
                this.worldObj.spawnParticle(EnumParticleTypes.SMOKE_LARGE,
                        this.posX + (this.rand.nextDouble() - 0.5D) * 1.2D,
                        this.posY + 0.2D + this.rand.nextDouble() * 1.6D,
                        this.posZ + (this.rand.nextDouble() - 0.5D) * 1.2D,
                        0.0D, 0.01D, 0.0D);
            }
        }
    }

    // ---- server brain ---------------------------------------------------------------------
    @Override
    protected void updateAITasks() {
        super.updateAITasks();
        if (this.worldObj.isRemote) return;

        EntityPlayer p = this.ownerId == null ? null : this.worldObj.getPlayerEntityByUUID(this.ownerId);
        if (p == null || p.isDead) { this.setDead(); return; }
        this.stateTicks++;
        this.lifeTicks++;
        if (this.attackCooldown > 0) this.attackCooldown--;
        this.updateAlpha();

        NullState st = this.getState();
        if (st != NullState.VANISHING && QuestData.isSealed(p)) { this.vanish(); return; }
        switch (st) {
            case OBSERVING:    this.tickObserving(p);   break;
            case STALKING:     this.tickStalking(p);    break;
            case DISTURBANCE:  this.tickDisturbance(p); break;
            case CHASE:        this.tickChase(p);       break;
            case JUMPSCARE:
                this.getNavigator().clearPathEntity();
                this.getLookHelper().setLookPositionWithEntity(p, 40.0F, 40.0F);
                if (this.stateTicks > 30) this.vanish();
                break;
            case VANISHING:
                this.getNavigator().clearPathEntity();
                if (this.stateTicks % 2 == 0) this.darkParticles(4);
                if (this.stateTicks >= VANISH_TICKS) this.setDead();
                break;
        }
    }

    /** Fade in when it appears, fade out when it vanishes: the entity blends into the environment. */
    private void updateAlpha() {
        NullState st = this.getState();
        float a;
        if (st == NullState.VANISHING) a = 1.0F - this.stateTicks / (float) VANISH_TICKS;
        else if (st == NullState.JUMPSCARE) a = 1.0F;
        else a = Math.min(1.0F, this.lifeTicks / (float) FADE_IN_TICKS);
        a = Math.max(0.0F, Math.min(1.0F, a));
        if (Math.abs(a - this.lastAlpha) > 0.02F || a >= 1.0F && this.lastAlpha < 1.0F) {
            this.dataManager.set(ALPHA, Float.valueOf(a));
            this.lastAlpha = a;
        }
    }

    // STATE 1: OBSERVING - stand still and watch
    private void tickObserving(EntityPlayer p) {
        this.getNavigator().clearPathEntity();
        this.getLookHelper().setLookPositionWithEntity(p, 30.0F, 30.0F);
        if (this.getDistanceToEntity(p) < 9.0F) { this.vanish(); return; }
        if (this.isLookedAt(p)) this.lookedTicks++; else this.lookedTicks = Math.max(0, this.lookedTicks - 1);
        if (this.lookedTicks > 50) { this.vanish(); return; }
        if (this.lifeTicks > this.maxLife) this.vanish();
    }

    // STATE 2: STALKING - creeps closer only while the player is not looking
    private void tickStalking(EntityPlayer p) {
        this.getLookHelper().setLookPositionWithEntity(p, 30.0F, 30.0F);
        double d = this.getDistanceToEntity(p);
        if (this.isLookedAt(p)) {
            this.lookedTicks++;
            this.getNavigator().clearPathEntity();
            if (this.lookedTicks > 25) { this.vanish(); return; }
        } else {
            this.lookedTicks = 0;
            if (d > 11.0D) {
                if (this.ticksExisted % 10 == 0) this.getNavigator().tryMoveToEntityLiving(p, 0.8D);
            } else {
                this.getNavigator().clearPathEntity();
            }
        }
        if (d < 14.0D && this.ticksExisted % 90 == 0) {
            this.worldObj.playSound(null, this.posX, this.posY, this.posZ, ModSounds.BREATH, SoundCategory.HOSTILE, 0.6F, 0.9F);
        }
        if (d < 6.0D) { this.vanish(); return; }
        if (this.lifeTicks > this.maxLife) {
            if (this.rand.nextFloat() < this.escalateChance) this.setState(NullState.CHASE); else this.vanish();
        }
    }

    // STATE 3: DISTURBANCE - waits in the distance while the director interferes with the world
    private void tickDisturbance(EntityPlayer p) {
        this.getNavigator().clearPathEntity();
        this.getLookHelper().setLookPositionWithEntity(p, 30.0F, 30.0F);
        if (this.lifeTicks > this.maxLife || this.getDistanceToEntity(p) < 6.0F) this.vanish();
    }

    // STATE 5: CHASE
    private void tickChase(EntityPlayer p) {
        double d = this.getDistanceToEntity(p);
        boolean sees = this.canEntityBeSeen(p);
        if (sees) {
            this.lastKnown = new BlockPos(p);
            this.searchTicks = 0;
            this.getLookHelper().setLookPositionWithEntity(p, 40.0F, 40.0F);
            if (this.ticksExisted % 8 == 0) this.getNavigator().tryMoveToEntityLiving(p, 1.0D);
        } else if (this.lastKnown != null) {
            if (this.ticksExisted % 10 == 0) {
                this.getNavigator().tryMoveToXYZ(this.lastKnown.getX() + 0.5D, this.lastKnown.getY(), this.lastKnown.getZ() + 0.5D, 1.0D);
            }
            if (this.getDistanceSq(this.lastKnown) < 6.0D) this.searchTicks++;
        } else {
            this.searchTicks++;
        }
        if (this.searchTicks > 120 && !this.ritual) { this.vanish(); return; }

        if (sees && d < 1.9D && this.attackCooldown <= 0) {
            this.swingArm(EnumHand.MAIN_HAND);
            float dmg = (float) this.getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).getAttributeValue();
            p.attackEntityFrom(DamageSource.causeMobDamage(this), dmg);
            this.attackCooldown = 20;
        }
        if (this.ticksExisted % 11 == 0) {
            this.worldObj.playSound(null, this.posX, this.posY, this.posZ, ModSounds.CHASE_STEP, SoundCategory.HOSTILE, 1.0F, 0.9F + this.rand.nextFloat() * 0.2F);
        }
        if (!this.ritual) {
            this.chaseTicksLeft--;
            if (this.chaseTicksLeft <= 0 || d > 56.0D) {
                QuestManager.onChaseSurvived(p);
                this.vanish();
            }
        }
    }

    // STATE 6: VANISHING
    public void vanish() {
        if (this.worldObj.isRemote || this.getState() == NullState.VANISHING) return;
        this.setState(NullState.VANISHING);
        this.getNavigator().clearPathEntity();
        this.worldObj.playSound(null, this.posX, this.posY, this.posZ, ModSounds.VANISH, SoundCategory.HOSTILE, 1.0F, 1.0F);
        this.darkParticles(25);
    }

    /** Final sealing: lifts the ritual lock, then vanishes with extra smoke. */
    public void sealAway() {
        this.ritual = false;
        this.vanish();
        this.darkParticles(60);
    }

    private void darkParticles(int n) {
        if (this.worldObj instanceof WorldServer) {
            ((WorldServer) this.worldObj).spawnParticle(EnumParticleTypes.SMOKE_LARGE, this.posX, this.posY + 1.0D, this.posZ, n, 0.3D, 0.8D, 0.3D, 0.02D);
        }
    }

    private boolean isLookedAt(EntityPlayer p) {
        Vec3d look = p.getLook(1.0F).normalize();
        Vec3d to = new Vec3d(this.posX - p.posX, (this.posY + this.getEyeHeight()) - (p.posY + p.getEyeHeight()), this.posZ - p.posZ);
        if (to.lengthVector() < 0.001D) return true;
        return look.dotProduct(to.normalize()) > 0.93D && p.canEntityBeSeen(this);
    }

    @Override
    public boolean attackEntityFrom(DamageSource src, float amount) {
        if (src == DamageSource.outOfWorld) return super.attackEntityFrom(src, amount);
        NullState st = this.getState();
        if (!this.worldObj.isRemote && src.getEntity() instanceof EntityPlayer
                && (st == NullState.OBSERVING || st == NullState.STALKING || st == NullState.DISTURBANCE)) {
            this.vanish();      // cannot be killed - it just leaves
        }
        return false;
    }
}
